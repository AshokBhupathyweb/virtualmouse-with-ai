# import cv2
# import os

# # Path to save the face images
# output_path = "E:/projects/ProjectFolder/face_data"
# os.makedirs(output_path, exist_ok=True)  # Create the directory if it doesn't exist

# # Initialize the webcam
# camera = cv2.VideoCapture(0)
# if not camera.isOpened():
#     print("Error: Unable to access the webcam.")
#     exit()

# # Load a pre-trained face detection model
# face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

# print("Press 'q' to quit or wait for the process to complete.")

# count = 0  # Counter for images captured
# max_photos = 100  # Number of photos to capture

# while True:
#     ret, frame = camera.read()
#     if not ret:
#         print("Error: Unable to capture video.")
#         break

#     # Convert to grayscale for face detection
#     gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#     faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

#     # Draw rectangles around detected faces
#     for (x, y, w, h) in faces:
#         cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

#         # Save the face region
#         if count < max_photos:
#             face_img = frame[y:y+h, x:x+w]
#             face_img = cv2.resize(face_img, (200, 200))  # Resize for consistency
#             filename = os.path.join(output_path, f"face_{count+1}.jpg")
#             cv2.imwrite(filename, face_img)
#             count += 1

#     # Display the count on the video frame
#     cv2.putText(frame, f"Captured: {count}/{max_photos}", (10, 30),
#                 cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

#     # Show the video feed with face detection
#     cv2.imshow("Face Capture", frame)

#     # Break if 'q' is pressed or the required number of photos is taken
#     if cv2.waitKey(1) & 0xFF == ord('q') or count >= max_photos:
#         break

# # Release the resources
# camera.release()
# cv2.destroyAllWindows()

# if count >= max_photos:
#     print(f"Successfully captured {max_photos} face photos in {output_path}.")
# else:
#     print(f"Process interrupted. {count} photos captured.")


# import cv2
# import os
# import time

# # Path to save the face images
# output_path = "E:/projects/ProjectFolder/face_data"
# os.makedirs(output_path, exist_ok=True)  # Create the directory if it doesn't exist

# # Initialize the webcam
# camera = cv2.VideoCapture(0)
# if not camera.isOpened():
#     print("Error: Unable to access the webcam.")
#     exit()

# # Load a pre-trained face detection model
# face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

# print("Capturing photos...")

# count = 0  # Counter for images captured
# max_photos = 100  # Number of photos to capture
# time_limit = 10  # Time limit in seconds

# # Start the timer
# start_time = time.time()

# while True:
#     ret, frame = camera.read()
#     if not ret:
#         print("Error: Unable to capture video.")
#         break

#     # Convert to grayscale for face detection
#     gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#     faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

#     # Draw rectangles around detected faces
#     for (x, y, w, h) in faces:
#         cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

#         # Save the face region
#         if count < max_photos:
#             face_img = frame[y:y+h, x:x+w]
#             face_img = cv2.resize(face_img, (200, 200))  # Resize for consistency
#             filename = os.path.join(output_path, f"face_{count+1}.jpg")
#             cv2.imwrite(filename, face_img)
#             count += 1

#     # Display the count and time remaining on the video frame
#     elapsed_time = time.time() - start_time
#     remaining_time = max(0, time_limit - elapsed_time)
#     cv2.putText(frame, f"Captured: {count}/{max_photos}", (10, 30),
#                 cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
#     cv2.putText(frame, f"Time Left: {remaining_time:.1f}s", (10, 70),
#                 cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

#     # Show the video feed with face detection
#     cv2.imshow("Face Capture", frame)

#     # Break if 'q' is pressed, the required number of photos is taken, or time limit is reached
#     if cv2.waitKey(1) & 0xFF == ord('q') or count >= max_photos or elapsed_time >= time_limit:
#         break

# # Release the resources
# camera.release()
# cv2.destroyAllWindows()

# # Summary of capture
# if count >= max_photos:
#     print(f"Successfully captured {max_photos} face photos in {output_path}.")
# elif elapsed_time >= time_limit:
#     print(f"Time limit reached. {count} photos captured in {output_path}.")
# else:
#     print(f"Process interrupted. {count} photos captured.")


# import cv2
# import os
# import time

# # Path to save the face images
# output_path = "E:/projects/ProjectFolder/face_data"
# os.makedirs(output_path, exist_ok=True)  # Create the directory if it doesn't exist

# # Initialize the webcam
# camera = cv2.VideoCapture(0)
# if not camera.isOpened():
#     print("Error: Unable to access the webcam.")
#     exit()

# # Load a pre-trained face detection model
# face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

# print("Capturing photos...")

# count = 0  # Counter for images captured
# max_photos = 500  # Number of photos to capture
# time_limit = 20  # Time limit in seconds

# # Start the timer
# start_time = time.time()

# while True:
#     ret, frame = camera.read()
#     if not ret:
#         print("Error: Unable to capture video.")
#         break

#     # Convert to grayscale for face detection
#     gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#     faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

#     # Draw rectangles around detected faces
#     for (x, y, w, h) in faces:
#         cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

#         # Save the face region
#         if count < max_photos:
#             face_img = frame[y:y+h, x:x+w]
#             face_img = cv2.resize(face_img, (200, 200))  # Resize for consistency
#             filename = os.path.join(output_path, f"face_{count+1}.jpg")
#             cv2.imwrite(filename, face_img)
#             count += 1

#     # Display the count and time remaining on the video frame
#     elapsed_time = time.time() - start_time
#     remaining_time = max(0, time_limit - elapsed_time)
#     cv2.putText(frame, f"Captured: {count}/{max_photos}", (10, 30),
#                 cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
#     cv2.putText(frame, f"Time Left: {remaining_time:.1f}s", (10, 70),
#                 cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

#     # Show the video feed with face detection
#     cv2.imshow("Face Capture", frame)

#     # Break if 'q' is pressed, the required number of photos is taken, or time limit is reached
#     if cv2.waitKey(1) & 0xFF == ord('q') or count >= max_photos or elapsed_time >= time_limit:
#         break

# # Release the resources
# camera.release()
# cv2.destroyAllWindows()

# # Summary of capture
# if count >= max_photos:
#     print(f"Successfully captured {max_photos} face photos in {output_path}.")
# elif elapsed_time >= time_limit:
#     print(f"Time limit reached. {count} photos captured in {output_path}.")
# else:
#     print(f"Process interrupted. {count} photos captured.")
#last worked 



# import cv2
# import os
# import time
# import openpyxl  # Import openpyxl for Excel file handling

# # Path to save the face images
# output_path = "E:/projects/ProjectFolder/face_data"
# os.makedirs(output_path, exist_ok=True)  # Create the directory if it doesn't exist

# # Initialize the webcam
# camera = cv2.VideoCapture(0)
# if not camera.isOpened():
#     print("Error: Unable to access the webcam.")
#     exit()

# # Load a pre-trained face detection model
# face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

# print("Capturing photos...")

# count = 0  # Counter for images captured
# max_photos = 500  # Number of photos to capture
# time_limit = 20  # Time limit in seconds

# # Start the timer
# start_time = time.time()

# while True:
#     ret, frame = camera.read()
#     if not ret:
#         print("Error: Unable to capture video.")
#         break

#     # Convert to grayscale for face detection
#     gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#     faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

#     # Draw rectangles around detected faces
#     for (x, y, w, h) in faces:
#         cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

#         # Save the face region
#         if count < max_photos:
#             face_img = frame[y:y+h, x:x+w]
#             face_img = cv2.resize(face_img, (200, 200))  # Resize for consistency
#             filename = os.path.join(output_path, f"face_{count+1}.jpg")
#             cv2.imwrite(filename, face_img)
#             count += 1

#     # Display the count and time remaining on the video frame
#     elapsed_time = time.time() - start_time
#     remaining_time = max(0, time_limit - elapsed_time)
#     cv2.putText(frame, f"Captured: {count}/{max_photos}", (10, 30),
#                 cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
#     cv2.putText(frame, f"Time Left: {remaining_time:.1f}s", (10, 70),
#                 cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

#     # Show the video feed with face detection
#     cv2.imshow("Face Capture", frame)

#     # Break if 'q' is pressed, the required number of photos is taken, or time limit is reached
#     if cv2.waitKey(1) & 0xFF == ord('q') or count >= max_photos or elapsed_time >= time_limit:
#         break

# # Release the resources
# camera.release()
# cv2.destroyAllWindows()

# # Ask for the user's name after capturing the photos
# user_name = input("Enter your name: ").strip()

# # Store data in Excel file
# excel_file = "E:/projects/ProjectFolder/face_data.xlsx"

# # Check if the Excel file exists
# if os.path.exists(excel_file):
#     # Load the existing workbook
#     workbook = openpyxl.load_workbook(excel_file)
#     sheet = workbook.active
# else:
#     # Create a new workbook if the file doesn't exist
#     workbook = openpyxl.Workbook()
#     sheet = workbook.active
#     sheet.append(["Name", "Captured Photos"])  # Adding headers if new file

# # Add the name and photo count to the Excel file
# sheet.append([user_name, count])

# # Save the Excel file
# workbook.save(excel_file)

# # Summary of capture
# if count >= max_photos:
#     print(f"Successfully captured {max_photos} face photos in {output_path}.")
# elif elapsed_time >= time_limit:
#     print(f"Time limit reached. {count} photos captured in {output_path}.")
# else:
#     print(f"Process interrupted. {count} photos captured.")


# import cv2
# import os
# import time
# import pandas as pd

# # Path to save the face images
# output_path = "E:/projects/ProjectFolder/face_data"
# os.makedirs(output_path, exist_ok=True)  # Create the directory if it doesn't exist

# # Initialize the webcam
# camera = cv2.VideoCapture(0)
# if not camera.isOpened():
#     print("Error: Unable to access the webcam.")
#     exit()

# # Load a pre-trained face detection model
# face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

# print("Capturing photos...")

# count = 0  # Counter for images captured
# max_photos = 500  # Number of photos to capture
# time_limit = 20  # Time limit in seconds

# # Start the timer
# start_time = time.time()

# while True:
#     ret, frame = camera.read()
#     if not ret:
#         print("Error: Unable to capture video.")
#         break

#     # Convert to grayscale for face detection
#     gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#     faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

#     # Draw rectangles around detected faces
#     for (x, y, w, h) in faces:
#         cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

#         # Save the face region
#         if count < max_photos:
#             face_img = frame[y:y+h, x:x+w]
#             face_img = cv2.resize(face_img, (200, 200))  # Resize for consistency
#             filename = os.path.join(output_path, f"face_{count+1}.jpg")
#             cv2.imwrite(filename, face_img)
#             count += 1

#     # Display the count and time remaining on the video frame
#     elapsed_time = time.time() - start_time
#     remaining_time = max(0, time_limit - elapsed_time)
#     cv2.putText(frame, f"Captured: {count}/{max_photos}", (10, 30),
#                 cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
#     cv2.putText(frame, f"Time Left: {remaining_time:.1f}s", (10, 70),
#                 cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

#     # Show the video feed with face detection
#     cv2.imshow("Face Capture", frame)

#     # Break if 'q' is pressed, the required number of photos is taken, or time limit is reached
#     if cv2.waitKey(1) & 0xFF == ord('q') or count >= max_photos or elapsed_time >= time_limit:
#         break

# # Release the resources
# camera.release()
# cv2.destroyAllWindows()

# # After capturing, ask for the name and store the data in an Excel file
# user_name = input("Enter your name: ")

# # Define the data to be added to the DataFrame
# data = [[user_name, count]]

# # Create or load the Excel file and append data
# excel_path = "E:/projects/ProjectFolder/user_data.xlsx"

# # Try to load the existing Excel file or create a new one
# try:
#     df = pd.read_excel(excel_path)
# except FileNotFoundError:
#     df = pd.DataFrame(columns=["Name", "Photos Captured"])

# # Append new data to the DataFrame
# df = pd.concat([df, pd.DataFrame(data, columns=["Name", "Photos Captured"])], ignore_index=True)

# # Save the updated DataFrame back to the Excel file
# df.to_excel(excel_path, index=False)

# print(f"Data successfully saved in {excel_path}")
#working 



import cv2
import os
import time
import pandas as pd

# Path to save the face images
output_path = "E:/projects/ProjectFolder/face_data"
os.makedirs(output_path, exist_ok=True)  # Create the directory if it doesn't exist

# Initialize the webcam with DirectShow backend for better compatibility
camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)
if not camera.isOpened():
    print("Error: Unable to access the webcam.")
    exit()

# Load a pre-trained face detection model
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

print("Capturing photos...")

count = 0  # Counter for images captured
max_photos = 500  # Number of photos to capture
time_limit = 20  # Time limit in seconds

# Start the timer
start_time = time.time()

while True:
    ret, frame = camera.read()
    if not ret:
        print("Error: Unable to capture video.")
        break

    # Convert to grayscale for face detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    # Draw rectangles around detected faces and save images
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

        if count < max_photos:
            face_img = frame[y:y+h, x:x+w]
            face_img = cv2.resize(face_img, (200, 200))  # Resize for consistency
            filename = os.path.join(output_path, f"face_{count+1}.jpg")
            cv2.imwrite(filename, face_img)
            count += 1

    # Display the count and time remaining on the video frame
    elapsed_time = time.time() - start_time
    remaining_time = max(0, time_limit - elapsed_time)
    cv2.putText(frame, f"Captured: {count}/{max_photos}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
    cv2.putText(frame, f"Time Left: {remaining_time:.1f}s", (10, 70),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

    # Show the video feed with face detection
    cv2.imshow("Face Capture", frame)

    # Break if 'q' is pressed, the required number of photos is taken, or time limit is reached
    if cv2.waitKey(1) & 0xFF == ord('q') or count >= max_photos or elapsed_time >= time_limit:
        break

# Release the resources
camera.release()
cv2.destroyAllWindows()

# After capturing, ask for the name and store the data in an Excel file
user_name = input("Enter your name: ")

data = [[user_name, count]]
excel_path = "E:/projects/ProjectFolder/user_data.xlsx"

try:
    df = pd.read_excel(excel_path)
except FileNotFoundError:
    df = pd.DataFrame(columns=["Name", "Photos Captured"])

# Append new data to the DataFrame
df = pd.concat([df, pd.DataFrame(data, columns=["Name", "Photos Captured"])], ignore_index=True)

df.to_excel(excel_path, index=False)
print(f"Data successfully saved in {excel_path}")

