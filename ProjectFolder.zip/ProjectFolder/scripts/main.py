# import cv2
# import face_recognition
# import numpy as np
# import os
# import cvzone
# from cvzone.HandTrackingModule import HandDetector
# import pyautogui

# # Paths
# face_data_path = "E:/projects/ProjectFolder/face_data"
# photo_files = [os.path.join(face_data_path, file) for file in os.listdir(face_data_path) if file.endswith('.jpg')]
# FACE_MATCH_THRESHOLD = 0.6

# # Virtual mouse variables
# wCam, hCam = 640, 480
# frameR = 100  # Frame reduction for mouse movement
# smoothening = 10  # Smooth movement
# INDEX_FINGER_TIP = 8  # Tip of index finger landmark
# MIDDLE_FINGER_TIP = 12  # Tip of middle finger landmark
# plocX, plocY = 0, 0
# clocX, clocY = 0, 0

# cap = cv2.VideoCapture(0)
# cap.set(3, wCam)  # Set width of capture window
# cap.set(4, hCam)  # Set height of capture window
# detector = HandDetector(maxHands=1)
# wScr, hScr = pyautogui.size()

# # Load face encodings only once
# face_encodings = []
# for photo_file in photo_files:
#     img = face_recognition.load_image_file(photo_file)
#     encodings = face_recognition.face_encodings(img)
#     face_encodings.extend(encodings)

# # Face authorization flag
# authorized = False

# frame_skip = 1  # Skip every X frames to reduce processing
# frame_count = 0

# while True:
#     success, frame = cap.read()
#     if not success:
#         continue

#     frame_count += 1

#     if frame_count % frame_skip != 0:  # Skip frames to reduce load
#         continue

#     gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#     faces = face_recognition.face_locations(frame)

#     for face_location in faces:
#         top, right, bottom, left = face_location
#         face_encoding = face_recognition.face_encodings(frame, [face_location])

#         if face_encoding:
#             matches = face_recognition.compare_faces(face_encodings, face_encoding[0], tolerance=FACE_MATCH_THRESHOLD)
#             face_distances = face_recognition.face_distance(face_encodings, face_encoding[0])

#             if any(matches):
#                 match_index = np.argmin(face_distances)
#                 label = "Authorized"
#                 color = (0, 255, 0)  # Green
#                 authorized = True
#             else:
#                 label = "Unauthorized"
#                 color = (0, 0, 255)  # Red
#                 authorized = False

#             cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
#             cv2.putText(frame, label, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

#     # If authorized, enable virtual mouse functionality
#     if authorized:
#         hands, frame = detector.findHands(frame, draw=True)

#         if hands:
#             hand = hands[0]
#             lmList = hand["lmList"]
#             if lmList:
#                 x1, y1 = lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]
#                 x2, y2 = lmList[MIDDLE_FINGER_TIP][0], lmList[MIDDLE_FINGER_TIP][1]

#             fingers = detector.fingersUp(hand)
#             cv2.rectangle(frame, (frameR, frameR), (wCam - frameR, hCam - frameR), (255, 0, 255), 2)

#             # Mouse Moving Mode
#             if fingers[1] == 1 and fingers[2] == 0:  # INDEX_FINGER and MIDDLE_FINGER
#                 scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
#                 scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))

#                 clocX = plocX + (scrCoordX - plocX) / smoothening
#                 clocY = plocY + (scrCoordY - plocY) / smoothening

#                 pyautogui.moveTo(wScr - clocX, clocY)
#                 cv2.circle(frame, (x1, y1), 15, (255, 0, 255), cv2.FILLED)
#                 plocX, plocY = clocX, clocY

#             # Mouse Clicking Mode
#             if fingers[1] == 1 and fingers[2] == 1:  # INDEX_FINGER and MIDDLE_FINGER
#                 length, lineInfo, frame = detector.findDistance(
#                     (lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]),
#                     (lmList[MIDDLE_FINGER_TIP][0], lmList[MIDDLE_FINGER_TIP][1]),
#                     frame
#                 )
#                 if length < 40:
#                     cv2.circle(frame, (lineInfo[4], lineInfo[5]), 15, (0, 255, 0), cv2.FILLED)
#                     pyautogui.click()

#     # Display the video feed
#     cv2.imshow("Face Authorization & Virtual Mouse", frame)

#     # Break the loop if 'q' is pressed
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# cap.release()
# cv2.destroyAllWindows()


#without right click


import cv2
import face_recognition
import numpy as np
import os
import cvzone
from cvzone.HandTrackingModule import HandDetector
import pyautogui

# Paths
face_data_path = "E:/projects/ProjectFolder/face_data"
photo_files = [os.path.join(face_data_path, file) for file in os.listdir(face_data_path) if file.endswith('.jpg')]
FACE_MATCH_THRESHOLD = 0.6

# Virtual mouse variables
wCam, hCam = 640, 480
frameR = 100  # Frame reduction for mouse movement
smoothening = 10  # Smooth movement
INDEX_FINGER_TIP = 8  # Tip of index finger landmark
MIDDLE_FINGER_TIP = 12  # Tip of middle finger landmark
THUMB_TIP = 4  # Tip of thumb landmark
plocX, plocY = 0, 0
clocX, clocY = 0, 0
dragging = False  # Flag for drag mode

cap = cv2.VideoCapture(0)
cap.set(3, wCam)  # Set width of capture window
cap.set(4, hCam)  # Set height of capture window
detector = HandDetector(maxHands=1)
wScr, hScr = pyautogui.size()

# Load face encodings only once
face_encodings = []
for photo_file in photo_files:
    img = face_recognition.load_image_file(photo_file)
    encodings = face_recognition.face_encodings(img)
    face_encodings.extend(encodings)

# Face authorization flag
authorized = False

frame_skip = 1  # Skip every X frames to reduce processing
frame_count = 0

while True:
    success, frame = cap.read()
    if not success:
        continue

    frame_count += 1

    if frame_count % frame_skip != 0:  # Skip frames to reduce load
        continue

    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_recognition.face_locations(frame)

    for face_location in faces:
        top, right, bottom, left = face_location
        face_encoding = face_recognition.face_encodings(frame, [face_location])

        if face_encoding:
            matches = face_recognition.compare_faces(face_encodings, face_encoding[0], tolerance=FACE_MATCH_THRESHOLD)
            face_distances = face_recognition.face_distance(face_encodings, face_encoding[0])

            if any(matches):
                match_index = np.argmin(face_distances)
                label = "Authorized"
                color = (0, 255, 0)  # Green
                authorized = True
            else:
                label = "Unauthorized"
                color = (0, 0, 255)  # Red
                authorized = False

            cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
            cv2.putText(frame, label, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

    # If authorized, enable virtual mouse functionality
    if authorized:
        hands, frame = detector.findHands(frame, draw=True)

        if hands:
            hand = hands[0]
            lmList = hand["lmList"]
            if lmList:
                x1, y1 = lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]
                x2, y2 = lmList[MIDDLE_FINGER_TIP][0], lmList[MIDDLE_FINGER_TIP][1]

            fingers = detector.fingersUp(hand)
            cv2.rectangle(frame, (frameR, frameR), (wCam - frameR, hCam - frameR), (255, 0, 255), 2)

            # Mouse Moving Mode
            if fingers[1] == 1 and fingers[2] == 0:  # INDEX_FINGER up and MIDDLE_FINGER down
                scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
                scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))

                clocX = plocX + (scrCoordX - plocX) / smoothening
                clocY = plocY + (scrCoordY - plocY) / smoothening

                pyautogui.moveTo(wScr - clocX, clocY)
                cv2.circle(frame, (x1, y1), 15, (255, 0, 255), cv2.FILLED)
                plocX, plocY = clocX, clocY

            # Left Click Mode
            if fingers[1] == 1 and fingers[2] == 1:  # INDEX_FINGER and MIDDLE_FINGER up
                length, lineInfo, frame = detector.findDistance(
                    (lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]),
                    (lmList[MIDDLE_FINGER_TIP][0], lmList[MIDDLE_FINGER_TIP][1]),
                    frame
                )
                if length < 40:
                    cv2.circle(frame, (lineInfo[4], lineInfo[5]), 15, (0, 255, 0), cv2.FILLED)
                    pyautogui.click()

            # Right Click Mode (Thumb Up)
            if fingers[0] == 1 and fingers[1] == 0 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0:  # Thumb up only
                cv2.circle(frame, (lmList[THUMB_TIP][0], lmList[THUMB_TIP][1]), 15, (0, 255, 255), cv2.FILLED)  # Yellow circle
                pyautogui.rightClick()

            # Dragging Mode (Pinch Gesture)
            if fingers[0] == 1 and fingers[1] == 1 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0:  # Thumb and index finger up
                length, lineInfo, frame = detector.findDistance(
                    (lmList[THUMB_TIP][0], lmList[THUMB_TIP][1]),
                    (lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]),
                    frame
                )
                if length < 40:  # If thumb and index are close enough
                    if not dragging:  # If dragging hasn't started
                        dragging = True
                        pyautogui.mouseDown()  # Start dragging
                    scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
                    scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))
                    pyautogui.moveTo(wScr - scrCoordX, scrCoordY)
                else:
                    if dragging:  # If dragging and fingers move apart
                        dragging = False
                        pyautogui.mouseUp()  # Stop dragging

    # Display the video feed
    cv2.imshow("Face Authorization & Virtual Mouse", frame)

    # Break the loop if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()