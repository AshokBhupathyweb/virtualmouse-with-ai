# import cv2
# import os
# import time
# import pandas as pd
# import numpy as np
# import pyautogui
# from cvzone.HandTrackingModule import HandDetector

# # Paths
# output_path = "E:/projects/ProjectFolder/face_data"
# os.makedirs(output_path, exist_ok=True)  # Create the directory if it doesn't exist

# # Initialize the webcam
# camera = cv2.VideoCapture(0)
# if not camera.isOpened():
#     print("Error: Unable to access the webcam.")
#     exit()

# # Load a pre-trained face detection model
# face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

# print("Capturing photos...")

# count = 0  # Counter for images captured
# max_photos = 500  # Number of photos to capture
# time_limit = 20  # Time limit in seconds

# # Start the timer
# start_time = time.time()

# while True:
#     ret, frame = camera.read()
#     if not ret:
#         print("Error: Unable to capture video.")
#         break

#     # Convert to grayscale for face detection
#     gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#     faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

#     # Draw rectangles around detected faces
#     for (x, y, w, h) in faces:
#         cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

#         # Save the face region
#         if count < max_photos:
#             face_img = frame[y:y+h, x:x+w]
#             face_img = cv2.resize(face_img, (200, 200))  # Resize for consistency
#             filename = os.path.join(output_path, f"face_{count+1}.jpg")
#             cv2.imwrite(filename, face_img)
#             count += 1

#     # Display the count and time remaining on the video frame
#     elapsed_time = time.time() - start_time
#     remaining_time = max(0, time_limit - elapsed_time)
#     cv2.putText(frame, f"Captured: {count}/{max_photos}", (10, 30),
#                 cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
#     cv2.putText(frame, f"Time Left: {remaining_time:.1f}s", (10, 70),
#                 cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

#     # Show the video feed with face detection
#     cv2.imshow("Face Capture", frame)

#     # Break if 'q' is pressed, the required number of photos is taken, or time limit is reached
#     if cv2.waitKey(1) & 0xFF == ord('q') or count >= max_photos or elapsed_time >= time_limit:
#         break

# # Release the resources
# camera.release()
# cv2.destroyAllWindows()

# # After capturing, ask for the name and store the data in an Excel file
# user_name = input("Enter your name: ")

# # Define the data to be added to the DataFrame
# data = [[user_name, count]]

# # Create or load the Excel file and append data
# excel_path = "E:/projects/ProjectFolder/user_data.xlsx"

# # Try to load the existing Excel file or create a new one
# try:
#     df = pd.read_excel(excel_path)
# except FileNotFoundError:
#     df = pd.DataFrame(columns=["Name", "Photos Captured"])

# # Append new data to the DataFrame
# df = pd.concat([df, pd.DataFrame(data, columns=["Name", "Photos Captured"])], ignore_index=True)

# # Save the updated DataFrame back to the Excel file
# df.to_excel(excel_path, index=False)

# print(f"Data successfully saved in {excel_path}")

# # Virtual Mouse & Hand Gestures for Volume Control (additional functionality)

# # Define HandDetector for hand gestures
# detector = HandDetector(maxHands=1)

# wCam, hCam = 640, 480
# frameR = 100  # Frame reduction for mouse movement
# smoothening = 10  # Smooth movement
# INDEX_FINGER_TIP = 8  # Tip of index finger landmark
# MIDDLE_FINGER_TIP = 12  # Tip of middle finger landmark
# THUMB_TIP = 4  # Tip of thumb landmark
# PINKY_TIP = 20  # Tip of pinky finger landmark
# plocX, plocY = 0, 0
# clocX, clocY = 0, 0
# dragging = False  # Flag for drag mode

# cap = cv2.VideoCapture(0)
# cap.set(3, wCam)  # Set width of capture window
# cap.set(4, hCam)  # Set height of capture window
# wScr, hScr = pyautogui.size()

# # Initialize volume control thresholds
# volume_threshold_min = 20  # Minimum distance (close enough)
# volume_threshold_max = 100  # Maximum distance (far enough to stop volume control)

# while True:
#     success, frame = cap.read()
#     if not success:
#         continue

#     # Detect hands and gestures
#     hands, frame = detector.findHands(frame, draw=True)
#     if hands:
#         hand = hands[0]
#         lmList = hand["lmList"]
#         if lmList:
#             x1, y1 = lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]
#             x2, y2 = lmList[MIDDLE_FINGER_TIP][0], lmList[MIDDLE_FINGER_TIP][1]
#             x3, y3 = lmList[THUMB_TIP][0], lmList[THUMB_TIP][1]
#             x4, y4 = lmList[PINKY_TIP][0], lmList[PINKY_TIP][1]

#         fingers = detector.fingersUp(hand)
#         cv2.rectangle(frame, (frameR, frameR), (wCam - frameR, hCam - frameR), (255, 0, 255), 2)

#         # Mouse Moving Mode
#         if fingers[1] == 1 and fingers[2] == 0:  # INDEX_FINGER up and MIDDLE_FINGER down
#             scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
#             scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))

#             clocX = plocX + (scrCoordX - plocX) / smoothening
#             clocY = plocY + (scrCoordY - plocY) / smoothening

#             pyautogui.moveTo(wScr - clocX, clocY)
#             cv2.circle(frame, (x1, y1), 15, (255, 0, 255), cv2.FILLED)
#             plocX, plocY = clocX, clocY

#         # Left Click Mode
#         if fingers[1] == 1 and fingers[2] == 1:  # INDEX_FINGER and MIDDLE_FINGER up
#             length, lineInfo, frame = detector.findDistance(
#                 (lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]),
#                 (lmList[MIDDLE_FINGER_TIP][0], lmList[MIDDLE_FINGER_TIP][1]),
#                 frame
#             )
#             if length < 40:
#                 cv2.circle(frame, (lineInfo[4], lineInfo[5]), 15, (0, 255, 0), cv2.FILLED)
#                 pyautogui.click()

#         # Right Click Mode (Thumb Up)
#         if fingers[0] == 1 and fingers[1] == 0 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0:  # Thumb up only
#             cv2.circle(frame, (lmList[THUMB_TIP][0], lmList[THUMB_TIP][1]), 15, (0, 255, 255), cv2.FILLED)  # Yellow circle
#             pyautogui.rightClick()

#         # Dragging Mode (Pinch Gesture)
#         if fingers[0] == 1 and fingers[1] == 1 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0:  # Thumb and index finger up
#             length, lineInfo, frame = detector.findDistance(
#                 (lmList[THUMB_TIP][0], lmList[THUMB_TIP][1]),
#                 (lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]),
#                 frame
#             )
#             if length < 40:  # If thumb and index are close enough
#                 if not dragging:  # If dragging hasn't started
#                     dragging = True
#                     pyautogui.mouseDown()  # Start dragging
#                 scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
#                 scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))
#                 pyautogui.moveTo(wScr - scrCoordX, scrCoordY)
#             else:
#                 if dragging:  # If dragging and fingers move apart
#                     dragging = False
#                     pyautogui.mouseUp()  # Stop dragging

#         # Volume Control (Thumb and index finger distance)
#         length, _, _ = detector.findDistance(
#             (lmList[THUMB_TIP][0], lmList[THUMB_TIP][1]),
#             (lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]),
#             frame
#         )

#         # Only trigger volume control if the distance is within a certain range
#         if volume_threshold_min < length < volume_threshold_max:
#             vol = np.interp(length, (20, 200), (0, 100))  # Adjust range as per your preference
#             if length > 150:
#                 pyautogui.press("volumeup")
#             else:
#                 pyautogui.press("volumedown")

#     # Display the video feed
#     cv2.imshow("Hand Gestures for Virtual Mouse", frame)

#     # Break the loop if 'q' is pressed
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# cap.release()
# cv2.destroyAllWindows()
# #fast working code but failure






# import cv2
# import os
# import time
# import pandas as pd
# import numpy as np
# import pyautogui
# from cvzone.HandTrackingModule import HandDetector
# from sklearn.metrics.pairwise import cosine_similarity

# # Paths
# face_data_path = "E:/projects/ProjectFolder/face_data"
# excel_path = "E:/projects/ProjectFolder/user_data.xlsx"

# # Load the Excel file to get the authorized users list
# try:
#     user_df = pd.read_excel(excel_path)
#     authorized_users = user_df["Name"].tolist()
# except FileNotFoundError:
#     print("Error: User data file not found.")
#     exit()

# # Load the pre-trained face detection model
# face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

# # Function to extract face embeddings
# def extract_face_embeddings(face_image):
#     gray = cv2.cvtColor(face_image, cv2.COLOR_BGR2GRAY)
#     gray = cv2.resize(gray, (100, 100)).flatten()  # Resize and flatten for comparison
#     return gray

# # Load stored face embeddings for comparison
# stored_faces = {}
# for filename in os.listdir(face_data_path):
#     if filename.endswith(".jpg") or filename.endswith(".png"):
#         img_path = os.path.join(face_data_path, filename)
#         img = cv2.imread(img_path)
#         if img is not None:
#             stored_faces[filename] = extract_face_embeddings(img)

# # Function to check if a face is authorized
# def is_authorized(face_img):
#     new_face_emb = extract_face_embeddings(face_img)
#     for stored_name, stored_emb in stored_faces.items():
#         similarity = cosine_similarity([new_face_emb], [stored_emb])[0][0]
#         if similarity > 0.85:  # Threshold for similarity
#             return stored_name.split("_")[0]  # Extract name from filename
#     return None

# # Virtual Mouse & Hand Gestures Setup
# detector = HandDetector(maxHands=1)
# wCam, hCam = 640, 480
# frameR = 100  # Frame reduction for mouse movement
# smoothening = 10  # Smooth movement
# INDEX_FINGER_TIP = 8
# MIDDLE_FINGER_TIP = 12
# THUMB_TIP = 4
# PINKY_TIP = 20
# plocX, plocY = 0, 0
# clocX, clocY = 0, 0
# dragging = False

# cap = cv2.VideoCapture(0)
# cap.set(3, wCam)
# cap.set(4, hCam)
# wScr, hScr = pyautogui.size()

# while True:
#     success, frame = cap.read()
#     if not success:
#         continue

#     # Convert frame to grayscale and detect faces
#     gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
#     faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(100, 100))

#     authorized_name = None
#     for (x, y, w, h) in faces:
#         face_img = frame[y:y+h, x:x+w]
#         detected_name = is_authorized(face_img)

#         if detected_name in authorized_users:
#             authorized_name = detected_name
#             cv2.putText(frame, f"Authorized: {authorized_name}", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
#             cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
#         else:
#             cv2.putText(frame, "Unauthorized", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
#             cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)

#     # If no authorized user is detected, skip hand gesture processing
#     if not authorized_name:
#         cv2.imshow("Hand Gestures for Virtual Mouse", frame)
#         if cv2.waitKey(1) & 0xFF == ord('q'):
#             break
#         continue

#     # Hand gesture detection
#     hands, frame = detector.findHands(frame, draw=True)
#     if hands:
#         hand = hands[0]
#         lmList = hand["lmList"]
#         if lmList:
#             x1, y1 = lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]
#             x2, y2 = lmList[MIDDLE_FINGER_TIP][0], lmList[MIDDLE_FINGER_TIP][1]
#             x3, y3 = lmList[THUMB_TIP][0], lmList[THUMB_TIP][1]
#             x4, y4 = lmList[PINKY_TIP][0], lmList[PINKY_TIP][1]

#         fingers = detector.fingersUp(hand)
#         cv2.rectangle(frame, (frameR, frameR), (wCam - frameR, hCam - frameR), (255, 0, 255), 2)

#         # Mouse Moving Mode
#         if fingers[1] == 1 and fingers[2] == 0:
#             scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
#             scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))

#             clocX = plocX + (scrCoordX - plocX) / smoothening
#             clocY = plocY + (scrCoordY - plocY) / smoothening

#             pyautogui.moveTo(wScr - clocX, clocY)
#             cv2.circle(frame, (x1, y1), 15, (255, 0, 255), cv2.FILLED)
#             plocX, plocY = clocX, clocY

#         # Left Click Mode
#         if fingers[1] == 1 and fingers[2] == 1:
#             length, _, frame = detector.findDistance((x1, y1), (x2, y2), frame)
#             if length < 40:
#                 cv2.circle(frame, (x1, y1), 15, (0, 255, 0), cv2.FILLED)
#                 pyautogui.click()

#         # Right Click Mode (Thumb Up)
#         if fingers[0] == 1 and sum(fingers[1:]) == 0:
#             cv2.circle(frame, (x3, y3), 15, (0, 255, 255), cv2.FILLED)
#             pyautogui.rightClick()

#         # Dragging Mode
#         if fingers[0] == 1 and fingers[1] == 1 and sum(fingers[2:]) == 0:
#             length, _, frame = detector.findDistance((x3, y3), (x1, y1), frame)
#             if length < 40:
#                 if not dragging:
#                     dragging = True
#                     pyautogui.mouseDown()
#                 scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
#                 scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))
#                 pyautogui.moveTo(wScr - scrCoordX, scrCoordY)
#             else:
#                 if dragging:
#                     dragging = False
#                     pyautogui.mouseUp()

#     cv2.imshow("Hand Gestures for Virtual Mouse", frame)
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# cap.release()
# cv2.destroyAllWindows()

# import cv2
# import os
# import time
# import pandas as pd
# import numpy as np
# import pyautogui
# import face_recognition
# from cvzone.HandTrackingModule import HandDetector
# from sklearn.metrics.pairwise import cosine_similarity

# # Paths
# face_data_path = "E:/projects/ProjectFolder/face_data"
# excel_path = "E:/projects/ProjectFolder/user_data.xlsx"
# wCam, hCam = 640, 480
# frameR = 100  # Frame reduction for mouse movement
# smoothening = 7  # Smooth movement

# # Define finger landmarks
# INDEX_FINGER_TIP = 8
# MIDDLE_FINGER_TIP = 12
# THUMB_TIP = 4
# FACE_MATCH_THRESHOLD = 0.6

# plocX, plocY = 0, 0
# clocX, clocY = 0, 0

# cap = cv2.VideoCapture(0)
# cap.set(3, wCam)
# cap.set(4, hCam)
# detector = HandDetector(maxHands=1)
# wScr, hScr = pyautogui.size()

# # Load face encodings
# face_encodings = []
# names = []

# try:
#     df = pd.read_excel(excel_path)
#     for _, row in df.iterrows():
#         name = row['Name']
#         photo_count = row['Photos Captured']
#         for i in range(photo_count):
#             img_path = os.path.join(face_data_path, f"face_{i + 1}.jpg")
#             if os.path.exists(img_path):
#                 img = face_recognition.load_image_file(img_path)
#                 encodings = face_recognition.face_encodings(img)
#                 if encodings:
#                     face_encodings.append(encodings[0])
#                     names.append(name)
# except FileNotFoundError:
#     print(f"{excel_path} not found.")
#     exit()

# # Face authorization flag
# authorized = False
# frame_skip = 2  # Skip every 2 frames to reduce processing
# frame_count = 0

# while True:
#     success, frame = cap.read()
#     if not success:
#         continue
    
#     frame_count += 1
#     if frame_count % frame_skip != 0:
#         continue
    
#     faces = face_recognition.face_locations(frame)
    
#     for face_location in faces:
#         top, right, bottom, left = face_location
#         face_encoding = face_recognition.face_encodings(frame, [face_location])

#         if face_encoding:
#             matches = face_recognition.compare_faces(face_encodings, face_encoding[0], tolerance=FACE_MATCH_THRESHOLD)
#             face_distances = face_recognition.face_distance(face_encodings, face_encoding[0])

#             if any(matches):
#                 match_index = np.argmin(face_distances)
#                 label = f"Authorized: {names[match_index]}"
#                 color = (0, 255, 0)
#                 authorized = True
#             else:
#                 label = "Unauthorized"
#                 color = (0, 0, 255)
#                 authorized = False
            
#             cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
#             cv2.putText(frame, label, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
    
#     if authorized:
#         hands, frame = detector.findHands(frame, draw=True)
#         if hands:
#             hand = hands[0]
#             lmList = hand["lmList"]
#             if lmList:
#                 x1, y1 = lmList[INDEX_FINGER_TIP][:2]
#                 x2, y2 = lmList[MIDDLE_FINGER_TIP][:2]
#                 fingers = detector.fingersUp(hand)

#                 cv2.rectangle(frame, (frameR, frameR), (wCam - frameR, hCam - frameR), (255, 0, 255), 2)

#                 # Mouse Move
#                 if fingers[1] == 1 and fingers[2] == 0:
#                     scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
#                     scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))
#                     clocX = plocX + (scrCoordX - plocX) / smoothening
#                     clocY = plocY + (scrCoordY - plocY) / smoothening
#                     pyautogui.moveTo(wScr - clocX, clocY)
#                     plocX, plocY = clocX, clocY
                
#                 # Dragging Mode (Pinch Gesture)
#                 if fingers[0] == 1 and fingers[1] == 1 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0:  # Thumb and index finger up
#                  length, lineInfo, frame = detector.findDistance(
#                     (lmList[THUMB_TIP][0], lmList[THUMB_TIP][1]),
#                     (lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]),
#                     frame
#                 )
#                  if length < 40:  # If thumb and index are close enough
#                     if not dragging:  # If dragging hasn't started
#                         dragging = True
#                         pyautogui.mouseDown()  # Start dragging
#                     scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
#                     scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))
#                     pyautogui.moveTo(wScr - scrCoordX, scrCoordY)
#                 else:
#                     if dragging:  # If dragging and fingers move apart
#                         dragging = False
#                         pyautogui.mouseUp()  # Stop dragging
                 
#                 # Left Click
#                 if fingers[1] == 1 and fingers[2] == 1:
#                     length, _, _ = detector.findDistance((x1, y1), (x2, y2))
#                     if length < 40:
#                         pyautogui.click()

#                 # Right Click (Thumb Up)
#                 if fingers[0] == 1 and sum(fingers[1:]) == 0:
#                     pyautogui.rightClick()

#     cv2.imshow("Virtual Mouse", frame)
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# cap.release()
# cv2.destroyAllWindows()
#remove drag option to amke it perfect





# import cv2
# import os
# import time
# import pandas as pd
# import numpy as np
# import pyautogui
# import face_recognition
# from cvzone.HandTrackingModule import HandDetector
# from sklearn.metrics.pairwise import cosine_similarity

# # Paths
# face_data_path = "E:/projects/ProjectFolder/face_data"
# excel_path = "E:/projects/ProjectFolder/user_data.xlsx"
# wCam, hCam = 640, 480
# frameR = 100  # Frame reduction for mouse movement
# smoothening = 7  # Smooth movement

# # Define finger landmarks
# INDEX_FINGER_TIP = 8
# MIDDLE_FINGER_TIP = 12
# THUMB_TIP = 4
# FACE_MATCH_THRESHOLD = 0.6

# plocX, plocY = 0, 0
# clocX, clocY = 0, 0

# dragging = False  # Fix: Initialize dragging

# cap = cv2.VideoCapture(0)
# cap.set(3, wCam)
# cap.set(4, hCam)
# detector = HandDetector(maxHands=1)
# wScr, hScr = pyautogui.size()

# # Load face encodings
# face_encodings = []
# names = []

# try:
#     df = pd.read_excel(excel_path)
#     for _, row in df.iterrows():
#         name = row['Name']
#         photo_count = row['Photos Captured']
#         for i in range(photo_count):
#             img_path = os.path.join(face_data_path, f"face_{i + 1}.jpg")
#             if os.path.exists(img_path):
#                 img = face_recognition.load_image_file(img_path)
#                 encodings = face_recognition.face_encodings(img)
#                 if encodings:
#                     face_encodings.append(encodings[0])
#                     names.append(name)
# except FileNotFoundError:
#     print(f"{excel_path} not found.")
#     exit()

# # Face authorization flag
# authorized = False
# frame_skip = 2  # Skip every 2 frames to reduce processing
# frame_count = 0

# while True:
#     success, frame = cap.read()
#     if not success:
#         continue
    
#     frame_count += 1
#     if frame_count % frame_skip != 0:
#         continue
    
#     faces = face_recognition.face_locations(frame)
    
#     for face_location in faces:
#         top, right, bottom, left = face_location
#         face_encoding = face_recognition.face_encodings(frame, [face_location])

#         if face_encoding:
#             matches = face_recognition.compare_faces(face_encodings, face_encoding[0], tolerance=FACE_MATCH_THRESHOLD)
#             face_distances = face_recognition.face_distance(face_encodings, face_encoding[0])

#             if any(matches):
#                 match_index = np.argmin(face_distances)
#                 label = f"Authorized: {names[match_index]}"
#                 color = (0, 255, 0)
#                 authorized = True
#             else:
#                 label = "Unauthorized"
#                 color = (0, 0, 255)
#                 authorized = False
            
#             cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
#             cv2.putText(frame, label, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
    
#     if authorized:
#         hands, frame = detector.findHands(frame, draw=True)
#         if hands:
#             hand = hands[0]
#             lmList = hand["lmList"]
#             if lmList:
#                 x1, y1 = lmList[INDEX_FINGER_TIP][:2]
#                 x2, y2 = lmList[MIDDLE_FINGER_TIP][:2]
#                 fingers = detector.fingersUp(hand)

#                 cv2.rectangle(frame, (frameR, frameR), (wCam - frameR, hCam - frameR), (255, 0, 255), 2)

#                 # Mouse Move
#                 if fingers[1] == 1 and fingers[2] == 0:
#                     scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
#                     scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))
#                     clocX = plocX + (scrCoordX - plocX) / smoothening
#                     clocY = plocY + (scrCoordY - plocY) / smoothening
#                     pyautogui.moveTo(wScr - clocX, clocY)
#                     plocX, plocY = clocX, clocY
                
#                 # Dragging Mode (Pinch Gesture)
#                 if fingers[0] == 1 and fingers[1] == 1 and fingers[2] == 0:
#                     length, _, _ = detector.findDistance(lmList[THUMB_TIP][:2], lmList[INDEX_FINGER_TIP][:2])
#                     if length < 40:
#                         if not dragging:
#                             dragging = True
#                             pyautogui.mouseDown()
#                         pyautogui.moveTo(wScr - x1, y1)
#                     else:
#                         if dragging:
#                             dragging = False
#                             pyautogui.mouseUp()
                
#                 # Left Click
#                 if fingers[1] == 1 and fingers[2] == 1:
#                     length, _, _ = detector.findDistance((x1, y1), (x2, y2))
#                     if length < 40:
#                         pyautogui.click()

#                 # Right Click (Thumb Up)
#                 if fingers[0] == 1 and sum(fingers[1:]) == 0:
#                     pyautogui.rightClick()

#     cv2.imshow("Virtual Mouse", frame)
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# cap.release()
# cv2.destroyAllWindows()
#not authorizing properly






# import cv2
# import os
# import numpy as np
# import pyautogui
# import pandas as pd
# import face_recognition
# from cvzone.HandTrackingModule import HandDetector

# # Disable PyAutoGUI Fail-Safe
# pyautogui.FAILSAFE = False  

# # Paths
# face_data_path = "E:/projects/ProjectFolder/face_data"
# excel_path = "E:/projects/ProjectFolder/user_data.xlsx"

# # Webcam Settings
# wCam, hCam = 640, 480
# frameR = 100  # Frame reduction for mouse movement
# smoothening = 7  # Smoother movement

# # Define finger landmarks
# INDEX_FINGER_TIP = 8
# MIDDLE_FINGER_TIP = 12
# THUMB_TIP = 4
# FACE_MATCH_THRESHOLD = 0.6

# # Initialize previous and current locations
# plocX, plocY = 0, 0
# clocX, clocY = 0, 0

# # Initialize video capture
# cap = cv2.VideoCapture(0)
# cap.set(3, wCam)
# cap.set(4, hCam)

# # Initialize Hand Detector
# detector = HandDetector(maxHands=1)
# wScr, hScr = pyautogui.size()

# # Load face encodings
# face_encodings = []
# names = []

# try:
#     df = pd.read_excel(excel_path)
#     for _, row in df.iterrows():
#         name = row['Name']
#         photo_count = row['Photos Captured']
#         for i in range(photo_count):
#             img_path = os.path.join(face_data_path, f"face_{i + 1}.jpg")
#             if os.path.exists(img_path):
#                 img = face_recognition.load_image_file(img_path)
#                 encodings = face_recognition.face_encodings(img)
#                 if encodings:
#                     face_encodings.append(encodings[0])
#                     names.append(name)
# except FileNotFoundError:
#     print(f"Error: {excel_path} not found.")
#     exit()

# # Dragging mode flag
# dragging = False  

# while True:
#     success, frame = cap.read()
#     if not success:
#         continue

#     faces = face_recognition.face_locations(frame)
#     authorized = False  # Reset authorization flag

#     for face_location in faces:
#         top, right, bottom, left = face_location
#         face_encoding = face_recognition.face_encodings(frame, [face_location])

#         if face_encoding and face_encodings:
#             face_encoding = face_encoding[0]
#             face_distances = face_recognition.face_distance(face_encodings, face_encoding)

#             if len(face_distances) > 0:
#                 best_match_index = np.argmin(face_distances)

#                 if face_distances[best_match_index] < FACE_MATCH_THRESHOLD:
#                     label = f"Authorized: {names[best_match_index]}"
#                     color = (0, 255, 0)  # Green for authorized
#                     authorized = True
#                 else:
#                     label = "Unauthorized"
#                     color = (0, 0, 255)  # Red for unauthorized

#                 cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
#                 cv2.putText(frame, label, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

#     if not authorized:
#         # Display "Unauthorized" on screen, but do not exit
#         cv2.putText(frame, "Unauthorized", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 3)

#     if authorized:
#         hands, frame = detector.findHands(frame, draw=True)
#         if hands:
#             hand = hands[0]
#             lmList = hand["lmList"]
#             if lmList:
#                 x1, y1 = lmList[INDEX_FINGER_TIP][:2]
#                 x2, y2 = lmList[MIDDLE_FINGER_TIP][:2]
#                 fingers = detector.fingersUp(hand)

#                 cv2.rectangle(frame, (frameR, frameR), (wCam - frameR, hCam - frameR), (255, 0, 255), 2)

#                 # Mouse Move
#                 if fingers[1] == 1 and fingers[2] == 0:
#                     scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
#                     scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))
#                     clocX = plocX + (scrCoordX - plocX) / smoothening
#                     clocY = plocY + (scrCoordY - plocY) / smoothening
#                     pyautogui.moveTo(wScr - clocX, clocY)
#                     plocX, plocY = clocX, clocY
                
#                 # Dragging Mode (Pinch Gesture)
#                 if fingers[0] == 1 and fingers[1] == 1 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0:
#                     length, _, frame = detector.findDistance(
#                         (lmList[THUMB_TIP][0], lmList[THUMB_TIP][1]),
#                         (lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]),
#                         frame
#                     )
#                     if length < 40:
#                         if not dragging:
#                             dragging = True
#                             pyautogui.mouseDown()
#                         scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
#                         scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))
#                         pyautogui.moveTo(wScr - scrCoordX, scrCoordY)
#                     else:
#                         if dragging:
#                             dragging = False
#                             pyautogui.mouseUp()
                 
#                 # Left Click
#                 if fingers[1] == 1 and fingers[2] == 1:
#                     length, _, _ = detector.findDistance((x1, y1), (x2, y2))
#                     if length < 40:
#                         pyautogui.click()

#                 # Right Click (Thumb Up)
#                 if fingers[0] == 1 and sum(fingers[1:]) == 0:
#                     pyautogui.rightClick()

#     cv2.imshow("Virtual Mouse", frame)
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# cap.release()
# cv2.destroyAllWindows()
#working 





import cv2
import os
import numpy as np
import pyautogui
import pandas as pd
import face_recognition
from cvzone.HandTrackingModule import HandDetector

# Disable PyAutoGUI Fail-Safe
pyautogui.FAILSAFE = False  

# Paths
face_data_path = "E:/projects/ProjectFolder/face_data"
excel_path = "E:/projects/ProjectFolder/user_data.xlsx"

# Webcam Settings
wCam, hCam = 640, 480
frameR = 100  
smoothening = 5  

# Define Finger Landmarks
INDEX_FINGER_TIP = 8
MIDDLE_FINGER_TIP = 12
THUMB_TIP = 4

# Improved Face Match Threshold (Lower = More Strict)
FACE_MATCH_THRESHOLD = 0.45  

# Screen Setup
wScr, hScr = pyautogui.size()

# Initialize previous and current locations
plocX, plocY = 0, 0
clocX, clocY = 0, 0

# Initialize Video Capture
cap = cv2.VideoCapture(0)
cap.set(3, wCam)
cap.set(4, hCam)

# Initialize Hand Detector
detector = HandDetector(maxHands=1)

# Load Face Encodings
face_encodings = []
names = []

try:
    df = pd.read_excel(excel_path)
    for _, row in df.iterrows():
        name = row['Name']
        photo_count = row['Photos Captured']
        for i in range(photo_count):
            img_path = os.path.join(face_data_path, f"face_{i + 1}.jpg")
            if os.path.exists(img_path):
                img = face_recognition.load_image_file(img_path)
                encodings = face_recognition.face_encodings(img)
                if encodings:
                    face_encodings.append(encodings[0])
                    names.append(name)
except FileNotFoundError:
    print(f"Error: {excel_path} not found.")
    exit()

dragging = False  

while True:
    success, frame = cap.read()
    if not success:
        continue

    # Convert to grayscale and improve contrast
    frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    frame = cv2.equalizeHist(frame_gray)

    # Convert back to BGR
    frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)

    faces = face_recognition.face_locations(frame)
    authorized = False  

    for face_location in faces:
        top, right, bottom, left = face_location
        face_encoding = face_recognition.face_encodings(frame, [face_location])

        if face_encoding and face_encodings:
            face_encoding = face_encoding[0]
            face_distances = face_recognition.face_distance(face_encodings, face_encoding)

            if len(face_distances) > 0:
                best_match_index = np.argmin(face_distances)

                if face_distances[best_match_index] < FACE_MATCH_THRESHOLD:
                    label = f"Authorized: {names[best_match_index]}"
                    color = (0, 255, 0)  
                    authorized = True
                else:
                    label = "Unauthorized"
                    color = (0, 0, 255)  

                cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
                cv2.putText(frame, label, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

    if not authorized:
        cv2.putText(frame, "Unauthorized", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 3)

    if authorized:
        hands, frame = detector.findHands(frame, draw=True)
        if hands:
            hand = hands[0]
            lmList = hand["lmList"]
            if lmList:
                x1, y1 = lmList[INDEX_FINGER_TIP][:2]
                x2, y2 = lmList[MIDDLE_FINGER_TIP][:2]
                fingers = detector.fingersUp(hand)

                cv2.rectangle(frame, (frameR, frameR), (wCam - frameR, hCam - frameR), (255, 0, 255), 2)

                # Mouse Move
                if fingers[1] == 1 and fingers[2] == 0:
                    scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
                    scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))
                    clocX = plocX + (scrCoordX - plocX) / smoothening
                    clocY = plocY + (scrCoordY - plocY) / smoothening
                    pyautogui.moveTo(wScr - clocX, clocY)
                    plocX, plocY = clocX, clocY
                
                # Dragging Mode
                if fingers[0] == 1 and fingers[1] == 1 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0:
                    length, _, frame = detector.findDistance(
                        (lmList[THUMB_TIP][0], lmList[THUMB_TIP][1]),
                        (lmList[INDEX_FINGER_TIP][0], lmList[INDEX_FINGER_TIP][1]),
                        frame
                    )
                    if length < 40:
                        if not dragging:
                            dragging = True
                            pyautogui.mouseDown()
                        scrCoordX = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
                        scrCoordY = np.interp(y1, (frameR, hCam - frameR), (0, hScr))
                        pyautogui.moveTo(wScr - scrCoordX, scrCoordY)
                    else:
                        if dragging:
                            dragging = False
                            pyautogui.mouseUp()
                 
                # Left Click
                if fingers[1] == 1 and fingers[2] == 1:
                    length, _, _ = detector.findDistance((x1, y1), (x2, y2))
                    if length < 40:
                        pyautogui.click()

                # Right Click
                if fingers[0] == 1 and sum(fingers[1:]) == 0:
                    pyautogui.rightClick()

    cv2.imshow("Virtual Mouse", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
