Project Overview:
This project integrates face recognition for security with virtual mouse control using hand gestures. It captures face images from the webcam, stores them, and uses these images for face recognition to authorize users. Once authorized, hand gestures are employed to control the mouse cursor and perform click actions.

Prerequisites:
Python Environment Setup:

Install Python 3.x if not already installed.
Create a virtual environment (optional but recommended).
Dependencies:

Install the required Python packages using pip:


pip install opencv-python
pip install face_recognition
pip install cvzone
pip install pyautogui
pip install dlib  # For face recognition

Directory Structure:

The project folder should have the following structure:


YourProject/
    ├── scripts/
        ├── capture_face.py  # Face capture script
        ├── main.py  # Main script handling face recognition & virtual mouse
        ├── dlib-<version>.whl  # Optional: dlib wheel file
    ├── face_data/  # Directory to store captured face images
Instructions to Use:


1. Face Capture Script (capture_face.py):
This script captures face images from the webcam and saves them in the face_data folder.
Run:

python scripts/capture_face.py
The script will:
Open the webcam.
Detect faces using the pre-trained Haar Cascade.
Capture a maximum of 500 photos or for a 20-second duration.
Save the detected face images into the face_data directory.


2. Main Script (main.py):
This script uses the captured face images to perform face recognition and control the virtual mouse.
Run:

python scripts/main.py
The script will:
Load the face encodings from the captured images.
Perform real-time face recognition to authorize users.
If authorized, use hand gestures to control the mouse cursor (moving and clicking).
Display video feed with mouse control and face recognition feedback.

Notes:

Ensure your webcam is connected and accessible via OpenCV (cv2.VideoCapture(0)).
Modify any paths if your project directory structure differs.
Adjust frame_skip and smoothening parameters in main.py to optimize performance based on your system.
dlib Installation (Optional):
If you encounter installation issues with dlib, you can manually install it using the provided wheel file.

Install using the wheel file:

pip install scripts/dlib-<version>.whl

Replace <version> with the appropriate version from your wheel file.

Project Files:
capture_face.py: Script to capture face images.
main.py: Main script for face recognition and virtual mouse control.
dlib-<version>.whl: dlib wheel file (if needed for installation issues).

now you can use the virtual mouse by running main.py file, after training the photos